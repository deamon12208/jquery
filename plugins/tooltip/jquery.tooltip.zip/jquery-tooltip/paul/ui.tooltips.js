;(function($) {

	$(document).ready(function() {
		$(".ui-show-tooltip").tooltip();
	});
	
	$.fn.extend({
		tooltip: function(options) {
			var args = Array.prototype.slice.call(arguments, 1);
			return this.each(function() {
				if (typeof options == "string") {
					var inst = $.data(this, "tooltip");
					if(inst) inst[options].apply(inst, args);
				} else if(!$.data(this, "tooltip"))
					new $.ui.tooltip(this, options);
			});
		}
	});
	
	$.ui.tooltip= function(element, options) {

		//Initialize needed constants
		var self = this;
		this.element = $(element);
		
		$.data(element, "tooltip", this);
		this.element.addClass("ui-show-tooltip");
		
		//Prepare the passed options
		this.options = $.extend({}, options);
		var o = this.options;
		$.extend(o, {
			appendTo: o.appendTo || "body",
			content: o.content || function(e,ui) { if(!ui.instance.cachedTitle) { ui.instance.cachedTitle = $(this).attr("title"); $(this).removeAttr("title"); } return ui.instance.cachedTitle.split(","); },
			tooltip: o.tooltip || function() { return $("<div>$0</div>")[0]; },
			cursorAt: o.cursorAt || [5,5],
			position: o.position || "mouse",
			fade: o.fade ? (parseInt(o.fade) || 500) : 500,
			delay: o.delay || 500
		});
		
		this.element
			.bind("setData.tooltip", function(event, key, value){
				self.options[key] = value;
			})
			.bind("getData.tooltip", function(event, key){
				return self.options[key];
			})
			.hover(function(e) {
				if(!self.options.disabled) {
					self.timeout = window.setTimeout(function() { self.over(e); }, self.options.delay);
				}
			}, function(e) {
				if(self.timeout) window.clearTimeout(self.timeout);
				if(!self.options.disabled && self.active) self.out(e);
			})
			.bind("mousemove", function(e) {
				if(!self.options.disabled) self.move(e);
			})
		;
		
		//Prepare cursorAt
		if(o.cursorAt && o.cursorAt.constructor == Array)
			o.cursorAt = { left: o.cursorAt[0], top: o.cursorAt[1] };	

		
	};
	
	$.extend($.ui.tooltip.prototype, {
		plugins: {},
		ui: function(e) {
			return {
				instance: this,
				options: this.options,
				element: this.element				
			};
		},
		propagate: function(n,e) {
			$.ui.plugin.call(this, n, [e, this.ui()]);
			return this.element.triggerHandler("tooltip"+n, [e, this.ui()], this.options[n]);
		},
		destroy: function() {
			if(!$.data(this.element[0], 'tooltip')) return;
			this.element
				.removeClass("ui-show-tooltip ui-tooltip-disabled")
				.removeData("tooltip")
				.unbind(".tooltip");
		},
		enable: function() {
			this.element.removeClass("ui-tooltip-disabled");
			this.options.disabled = false;
		},
		disable: function() {
			this.element.addClass("ui-tooltip-disabled");
			this.options.disabled = true;
		},
		over: function(e) {

			var o = this.options;
			
			//Create and append the visible helper
			if(!o.cache || !this.tooltip) {
				this.tooltip = $(o.tooltip.apply(this.element[0], [e])).css({ position: "absolute" }).addClass("ui-tooltip");
				if(!this.tooltip.parents('body').length) this.tooltip.appendTo((o.appendTo == 'parent' ? this.element[0].parentNode : o.appendTo));
				if(o.width) this.tooltip.css("width", o.width);
				if(o.height) this.tooltip.css("width", o.height);
			}
			
			//Append content pieces
			var content = o.content.call(this.element[0], e, this.ui());
			var html = this.tooltip[0].innerHTML;
			for (var i=0; i < content.length; i++) { html = html.replace("$"+i, content[i]); };
			this.tooltip[0].innerHTML = html;
			
			//Generate offsets
			this.offsetParentOffset = this.tooltip.show().css("opacity", 0).offsetParent().offset();
			this.offset = this.element.offset();

			//Set the initial position
			if(o.position == "mouse") {
				this.position = {
					left: (this.event || e).pageX + this.options.cursorAt.left - this.offsetParentOffset.left,
					top: (this.event || e).pageY + this.options.cursorAt.top - this.offsetParentOffset.top
				};
				
				this.tooltip.css(this.position);
			}

			//Set th   SCCA   J&  R U B Y . E X E   /�    �	�     �|     p     ��(	�@���P�6    �         8  �  H  �#     b  �x@�C�� ��G     ��G    �         4       0      4   ?   b   3      s      �   2      x      0  1      y      �  3      }      �  +         �   T  0           �  1        �     .      �  !   x  3      �     �  1      �     D  1           �  0      &     
  0      -     l  )      0     �  0      6     "  _      7     �  2            ��       ��     $  ����    4  ����    D  ����    T  ����    d  ����    t  ����	    �  ����
    �  ����    �  ����    �  ����    �  ��     �  ��     �  ����    �  ����     ����     ���